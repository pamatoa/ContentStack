function WeatherTable(){ 
  const url = "https://mjgh1cx0le.execute-api.us-west-1.amazonaws.com/default/weatherAPI"
  const req = new XMLHttpRequest();
  req.open("GET", url, true);
  req.send();
  req.onload = () => {
  const weather = JSON.parse(req.responseText);
  console.log(weather);
  let time = "Time: " + weather.weather.time;
  let location = "Location: " + weather.weather.location;
  let wind = "Wind Direction and Speed: " + weather.weather.wind;
  let temperature_current = "Current Temp: " + weather.weather.temperature_current;
  let temperature_low = "Low Temp: " + weather.weather.temperature_low;
  let temperature_high = "High Temp: " + weather.weather.temperature_high;
  let precipitation = "Chance of Precipitation: " + weather.weather.precipitation;
  let humidity = "Humidity: " + weather.weather.humidity;
  let icon_weather = '<img src=' + weather.weather.icon_weather + ' alt="Weather Icon" width="75" height="75"/>';

console.log(time);
console.log(location);
console.log(wind);
console.log(temperature_current);
console.log(temperature_low);
console.log(temperature_high);
console.log(precipitation);
console.log(humidity);
console.log(icon_weather);

    return (
    <div className="weather-container">
      <table>
        <tr>
          <div className="table-header">
            <th>Weather API Results</th>
            <p>Feel free to get creative!</p>
          </div>
        
          <td className="center">RESULTS HERE
          <p>time</p>
          <p>location</p>
          </td>
        </tr>
      </table>
    </div>
  );
}}
export default WeatherTable;
