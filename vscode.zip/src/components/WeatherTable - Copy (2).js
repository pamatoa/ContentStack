function WeatherTable() {
<script>
  fetch(https://mjgh1cx0le.execute-api.us-west-1.amazonaws.com/default/weatherAPI)
  .then(function(response)return response.json();)
  .then(function(weather)
    let weatherdata = document.querySelector("#data-output");
    let out = "";
        out += `<tr>
              <td>${'location'}</td>
              <td>${'wind'}</td>
              <td>${'temperature_current'}</td>
        </tr>
        `
        
  console.log(out);
  document.getElementById(weatherdata).innerHTML = out;
    placeholder.innerHTML = out;
);
</script>

  return (
    <div className="weather-container">
      <table>
        <tr>
          <div className="table-header">
            <th>Weather API Results</th>
            <p>Feel free to get creative!</p>
          </div>
        </tr>
        <tr>
          <td className="center">RESULTS HERE</td>

<tr>
<p>asdfghjkl;</p>
</tr>           
        </tr>
      </table>
    </div>
  );
 
  }

 
export default WeatherTable;
