function Footer() {
    return (
  
      <div className="footer">
          <p>© Contentstack 2021</p>
      </div>
    );
  }
  export default Footer;