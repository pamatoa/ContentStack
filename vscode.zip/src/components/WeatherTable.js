function WeatherTable() {
  
  const url = "https://mjgh1cx0le.execute-api.us-west-1.amazonaws.com/default/weatherAPI";
  
  const req = new XMLHttpRequest();
  req.open("GET", url);
  req.send();
  req.onload = () => {
    const weatherdata = JSON.parse(req.responseText);
    //const weather = JSON.stringify(weatherdata);
    console.log(weatherdata);
    //console.log(weather);
    //console.log(weatherdata.weather.time)
    //console.log(weatherdata.weather.location);
    const time = weatherdata.weather.time;
    const location = weatherdata.weather.location;
 //   
 //   const fragment = document.createDocumentFragment();
 //   const li = fragment
 //     .appendChild(document.createElement('section'))
 //     .appendChild(document.createElement('ul'))
 //     .appendChild(document.createElement('li'));
 //       li.textContent = location;
 //   document.body.appendChild(fragment);

    /*  
//const para = document.createElement("div")
//const node = document.createElement(`${time}`);
//para.appendChild(node);
//document.getElementById("myDIV").appendChild(para)
//node = document.createElement(`${location}`);
//console.log(`${location}`)
//para.append(node);
//document.getElementById("myDIV").appendChild(para)
*/
  };
  return (
    <div className="weather-container">
      <table>
        <tr>
          <div className="table-header">
            <th>Weather API Results</th>
            <p>Feel free to get creative!</p>
          </div>
        </tr>
          <tr>
            <td className="center">
              RESULTS HERE
              <div id="myDIV"></div>  

            </td>
          </tr>
      </table>
    </div>
  )
}
export default WeatherTable;