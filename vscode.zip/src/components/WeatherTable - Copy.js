function WeatherTable() {
  const url = "https://mjgh1cx0le.execute-api.us-west-1.amazonaws.com/default/weatherAPI"
  fetch(url)
  .then(function(response) {return response.json()})
  .then(function(weather){
    weather.humidity.innerHTML = document.getElementById('weather.humidity');
   let temperature = document.getElementById('weather.temp');
   let location = document.getElementById('weather.location');
    })
  .then(function(weather) {return console.log(weather)});

 
  
    return (
    <div className="weather-container">
      <table>
        <tr>
          <div className="table-header">
            <th>Weather API Results</th>
            <p>Feel free to get creative!</p>
          </div>
        </tr>
          <tr>
          <td className="center">RESULTS HERE</td>
          <div id= "weather.humidity"></div>
          <div id= "weather.temp"></div>
          <div id= "weather.location"></div>
        </tr>
      </table>
    </div>
  );
}
export default WeatherTable;
