function WeatherTable() {
  const url = `https://mjgh1cx0le.execute-api.us-west-1.amazonaws.com/default/weatherAPI`;
<script>
{
// Using fetch to get data
fetch(url)
  .then((response) => {response.json()})
  .then((weather) => {
   let humidity = document.getElementById('weather.humidity');
   let temperature = document.getElementById('weather.weather.temp');
   let location = document.getElementById('weather.weather.location');
  console.log(humidity);
  console.log(temperature);
  console.log(location);
  })
  .then((weather) => {console.log(weather)})
}

  </script>

return (
    <div className="weather-container">
      <table>
        <tr>
          <div className="table-header">
            <th>Weather API Results</th>
            <p>Feel free to get creative!</p>
          </div>
        </tr>
        <tr>
          <td className="center">RESULTS HERE
          <p>asasdfasdfdfa</p>
          </td>
        </tr>
      </table>
    </div>
  );
}
export default WeatherTable;