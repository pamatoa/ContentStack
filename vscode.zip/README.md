To run the app locally:

`npm i`

`npm start`

Instructions provided via email. 
Contact muhammed.constantino@contentstack.com with any questions.
